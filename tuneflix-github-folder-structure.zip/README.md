# Tuneflix Full-Stack Starter

## Folder structure
- backend/server.js — Express backend, API, login, database operations
- frontend/public/index.html — Black & White dashboard frontend
- config/.env.example — environment-variable template
- package.json — project dependencies and start command
- uploads/ — created automatically for uploaded audio/cover files

## GitHub
Upload the CONTENTS of this folder into the ROOT of your GitHub repository. Do not upload the ZIP itself and do not add an extra nested project folder.

## Render settings
Build command: npm install
Start command: npm start

Copy config/.env.example values into Render Environment settings. Set DATABASE_URL to your Render PostgreSQL connection string, JWT_SECRET to a long random secret, ADMIN_EMAIL and a strong ADMIN_PASSWORD. Set PGSSL=true if your database requires SSL.

## Important
This is a standalone starter, not a direct patch to your current live Tuneflix app. Back up your existing repository and reconcile its database, login, APIs and uploads before deploying. Do not overwrite the live website blindly.

Real DSP stream analytics, OTT delivery, royalty imports, actual bank/UPI payouts, email verification, password reset, audit logs and production object storage are not included yet and require integration/testing.
