require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const { Pool } = require("pg");

const app = express();
const PORT = process.env.PORT || 10000;
const JWT_SECRET = process.env.JWT_SECRET;
if (!process.env.DATABASE_URL || !JWT_SECRET) {
  console.error("Missing DATABASE_URL or JWT_SECRET in environment.");
  process.exit(1);
}
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.PGSSL === "true" ? { rejectUnauthorized: false } : undefined
});

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(",").map(s => s.trim()) : true }));
app.use(express.json({ limit: "2mb" }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 300 }));
app.use("/uploads", express.static(path.join(__dirname, "..", "uploads")));
app.use(express.static(path.join(__dirname, "..", "frontend", "public")));

const uploadDir = path.join(__dirname, "..", "uploads");
fs.mkdirSync(uploadDir, { recursive: true });
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => cb(null, `${Date.now()}-${Math.random().toString(36).slice(2)}${path.extname(file.originalname).toLowerCase()}`)
});
const upload = multer({
  storage,
  limits: { fileSize: 100 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = /^(audio\/(mpeg|wav|mp4|x-wav)|image\/(jpeg|png|webp))$/i.test(file.mimetype);
    cb(allowed ? null : new Error("Only audio (MP3/WAV) and image (JPG/PNG/WebP) files are allowed."), allowed);
  }
});

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'artist',
      status TEXT NOT NULL DEFAULT 'pending', created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS labels (
      id SERIAL PRIMARY KEY, name TEXT NOT NULL, email TEXT, status TEXT DEFAULT 'active',
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS releases (
      id SERIAL PRIMARY KEY, title TEXT NOT NULL, artist TEXT NOT NULL,
      label TEXT, upc TEXT, release_date DATE, status TEXT NOT NULL DEFAULT 'pending',
      audio_path TEXT, cover_path TEXT, created_by INTEGER REFERENCES users(id),
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS wallet_transactions (
      id SERIAL PRIMARY KEY, user_id INTEGER REFERENCES users(id),
      amount NUMERIC(12,2) NOT NULL, type TEXT NOT NULL,
      note TEXT, status TEXT NOT NULL DEFAULT 'completed',
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS support_tickets (
      id SERIAL PRIMARY KEY, user_id INTEGER REFERENCES users(id),
      subject TEXT NOT NULL, message TEXT NOT NULL, status TEXT DEFAULT 'open',
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS notifications (
      id SERIAL PRIMARY KEY, title TEXT NOT NULL, message TEXT NOT NULL,
      is_read BOOLEAN DEFAULT FALSE, created_at TIMESTAMPTZ DEFAULT NOW()
    );
  `);
  const email = (process.env.ADMIN_EMAIL || "").toLowerCase().trim();
  const password = process.env.ADMIN_PASSWORD || "";
  if (email && password && password !== "ChangeThisPassword123!") {
    const existing = await pool.query("SELECT id FROM users WHERE email=$1", [email]);
    if (!existing.rowCount) {
      const hash = await bcrypt.hash(password, 12);
      await pool.query(
        "INSERT INTO users(name,email,password_hash,role,status) VALUES($1,$2,$3,'admin','approved')",
        [process.env.ADMIN_NAME || "Admin", email, hash]
      );
      console.log("Initial admin account created from environment variables.");
    }
  }
}

function auth(req, res, next) {
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (!token) return res.status(401).json({ error: "Please sign in." });
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { return res.status(401).json({ error: "Session expired. Please sign in again." }); }
}
function adminOnly(req, res, next) {
  if (req.user?.role !== "admin") return res.status(403).json({ error: "Admin access required." });
  next();
}
const wrap = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "tuneflix-api" }));

app.post("/api/auth/login", wrap(async (req, res) => {
  const email = String(req.body.email || "").toLowerCase().trim();
  const password = String(req.body.password || "");
  const result = await pool.query("SELECT id,name,email,password_hash,role,status FROM users WHERE email=$1", [email]);
  const user = result.rows[0];
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: "Invalid email or password." });
  if (user.status !== "approved") return res.status(403).json({ error: "Your account is not approved yet." });
  const token = jwt.sign({ id: user.id, name: user.name, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: "12h" });
  res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
}));
app.get("/api/auth/me", auth, (req, res) => res.json({ user: req.user }));

app.get("/api/dashboard", auth, adminOnly, wrap(async (_req, res) => {
  const [users, pending, releases, requests, earnings, recent] = await Promise.all([
    pool.query("SELECT COUNT(*)::int AS n FROM users"),
    pool.query("SELECT COUNT(*)::int AS n FROM users WHERE status='pending'"),
    pool.query("SELECT COUNT(*)::int AS n FROM releases"),
    pool.query("SELECT COUNT(*)::int AS n FROM support_tickets WHERE status='open'"),
    pool.query("SELECT COALESCE(SUM(amount),0)::numeric(12,2) AS n FROM wallet_transactions WHERE type='credit' AND status='completed'"),
    pool.query("SELECT id,title,artist,status,created_at FROM releases ORDER BY created_at DESC LIMIT 6")
  ]);
  res.json({
    stats: { users: users.rows[0].n, pending: pending.rows[0].n, releases: releases.rows[0].n, requests: requests.rows[0].n, earnings: earnings.rows[0].n },
    recentReleases: recent.rows
  });
}));

app.get("/api/users", auth, adminOnly, wrap(async (req, res) => {
  const status = req.query.status;
  const q = status ? await pool.query("SELECT id,name,email,role,status,created_at FROM users WHERE status=$1 ORDER BY created_at DESC", [status])
                   : await pool.query("SELECT id,name,email,role,status,created_at FROM users ORDER BY created_at DESC");
  res.json(q.rows);
}));
app.post("/api/users/register", wrap(async (req, res) => {
  const name = String(req.body.name || "").trim();
  const email = String(req.body.email || "").toLowerCase().trim();
  const password = String(req.body.password || "");
  if (!name || !email || password.length < 10) return res.status(400).json({ error: "Name, valid email and password (minimum 10 characters) are required." });
  const hash = await bcrypt.hash(password, 12);
  const result = await pool.query("INSERT INTO users(name,email,password_hash,role,status) VALUES($1,$2,$3,'artist','pending') RETURNING id,name,email,status", [name,email,hash]);
  res.status(201).json({ message: "Application submitted for admin approval.", user: result.rows[0] });
}));
app.patch("/api/users/:id/status", auth, adminOnly, wrap(async (req, res) => {
  const status = req.body.status;
  if (!["approved","rejected","pending"].includes(status)) return res.status(400).json({ error: "Invalid status." });
  const result = await pool.query("UPDATE users SET status=$1 WHERE id=$2 RETURNING id,name,email,role,status", [status, req.params.id]);
  if (!result.rowCount) return res.status(404).json({ error: "User not found." });
  res.json(result.rows[0]);
}));

app.get("/api/labels", auth, adminOnly, wrap(async (_req,res) => res.json((await pool.query("SELECT * FROM labels ORDER BY created_at DESC")).rows)));
app.post("/api/labels", auth, adminOnly, wrap(async (req,res) => {
  const name = String(req.body.name || "").trim();
  if (!name) return res.status(400).json({ error: "Label name is required." });
  const r = await pool.query("INSERT INTO labels(name,email,status) VALUES($1,$2,'active') RETURNING *", [name, req.body.email || null]);
  res.status(201).json(r.rows[0]);
}));

app.get("/api/releases", auth, adminOnly, wrap(async (_req,res) => res.json((await pool.query("SELECT * FROM releases ORDER BY created_at DESC")).rows)));
app.post("/api/releases", auth, upload.fields([{name:"audio",maxCount:1},{name:"cover",maxCount:1}]), wrap(async (req,res) => {
  const { title, artist, label, upc, release_date } = req.body;
  if (!title || !artist) return res.status(400).json({ error: "Title and artist are required." });
  const audio = req.files?.audio?.[0];
  const cover = req.files?.cover?.[0];
  const r = await pool.query(
    "INSERT INTO releases(title,artist,label,upc,release_date,status,audio_path,cover_path,created_by) VALUES($1,$2,$3,$4,$5,'pending',$6,$7,$8) RETURNING *",
    [title,artist,label || null,upc || null,release_date || null,audio ? `/uploads/${audio.filename}` : null,cover ? `/uploads/${cover.filename}` : null,req.user?.id || null]
  );
  res.status(201).json(r.rows[0]);
}));
app.patch("/api/releases/:id/status", auth, adminOnly, wrap(async (req,res) => {
  const status = req.body.status;
  if (!["approved","rejected","pending"].includes(status)) return res.status(400).json({ error: "Invalid status." });
  const r = await pool.query("UPDATE releases SET status=$1 WHERE id=$2 RETURNING *", [status,req.params.id]);
  if (!r.rowCount) return res.status(404).json({ error: "Release not found." });
  res.json(r.rows[0]);
}));

app.get("/api/wallet/transactions", auth, adminOnly, wrap(async (_req,res) => res.json((await pool.query("SELECT wt.*,u.name,u.email FROM wallet_transactions wt LEFT JOIN users u ON u.id=wt.user_id ORDER BY wt.created_at DESC LIMIT 100")).rows)));
app.post("/api/wallet/transactions", auth, adminOnly, wrap(async (req,res) => {
  const amount = Number(req.body.amount);
  const type = req.body.type;
  if (!Number.isFinite(amount) || amount <= 0 || !["credit","debit"].includes(type)) return res.status(400).json({ error: "Enter a positive amount and credit/debit type." });
  const r = await pool.query("INSERT INTO wallet_transactions(user_id,amount,type,note,status) VALUES($1,$2,$3,$4,'completed') RETURNING *", [req.body.user_id || null,amount,type,req.body.note || null]);
  res.status(201).json(r.rows[0]);
}));
app.get("/api/support", auth, adminOnly, wrap(async (_req,res) => res.json((await pool.query("SELECT t.*,u.name,u.email FROM support_tickets t LEFT JOIN users u ON u.id=t.user_id ORDER BY t.created_at DESC")).rows)));
app.post("/api/support", auth, wrap(async (req,res) => {
  const subject = String(req.body.subject || "").trim(), message = String(req.body.message || "").trim();
  if (!subject || !message) return res.status(400).json({ error: "Subject and message are required." });
  const r = await pool.query("INSERT INTO support_tickets(user_id,subject,message) VALUES($1,$2,$3) RETURNING *", [req.user.id,subject,message]);
  res.status(201).json(r.rows[0]);
}));
app.get("/api/notifications", auth, adminOnly, wrap(async (_req,res) => res.json((await pool.query("SELECT * FROM notifications ORDER BY created_at DESC LIMIT 50")).rows)));
app.post("/api/notifications", auth, adminOnly, wrap(async (req,res) => {
  const title = String(req.body.title || "").trim(), message = String(req.body.message || "").trim();
  if (!title || !message) return res.status(400).json({ error: "Title and message are required." });
  const r = await pool.query("INSERT INTO notifications(title,message) VALUES($1,$2) RETURNING *", [title,message]);
  res.status(201).json(r.rows[0]);
}));

app.get("*", (_req,res) => res.sendFile(path.join(__dirname,"public","index.html")));
app.use((err,_req,res,_next) => {
  console.error(err);
  res.status(err.status || 500).json({ error: err.message || "Server error." });
});

initDb().then(() => app.listen(PORT, () => console.log(`Tuneflix running on ${PORT}`)))
  .catch(err => { console.error("Database initialization failed:", err); process.exit(1); });
